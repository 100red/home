from gamewindow import GameWindow

window = GameWindow()